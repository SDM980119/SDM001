import datetime

from pygments.lexer import default

from main import db


#####################################################################################

# primary_key = 해당 컬럼을 기본키로 설정
#               보통 id 컬럼에 많이 사용함
#               중복, NULL 불가

# unique = 해당 컬럼 값이 테이블 안에서 유일해야함
#          이메일, 주민등록번호 같은 데이터에 주로 사용

# nullable = NULL 값을 허용할지 정할수 있음
#            False로 설정시 값이 들어가야함
#            비울수 없는 컬럼에서 사용해야함

# autoincrement = 정수형 컬럼에서 주로 사용, 새 레코드가 들어올 때마다 값이 자동으로 증가함
#                 주로 id컬럼에서 사용함

# ondelete='CASCADE' = 글 작성자가 탈퇴시 작성했던 글 삭제
#                      그냥 두면 오류가 발생할수 있기 때문에 삭제

#####################################################################################

class User(db.Model):                                                                                       # 사용자
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)                                                            # user 테이블에 유저 정보가 저장되면 생성 순서대로 자동으로 만들어짐
    email = db.Column(db.String(50), unique=True, nullable=False)                                           # 이메일
    userid = db.Column(db.String(50), unique=True, nullable=False)                                          # 아이디
    password = db.Column(db.String(80), nullable=False)                                                     # 비밀번호
    username = db.Column(db.String(80), unique=True, nullable=False)                                        # 닉네임
    birthday = db.Column(db.DateTime, nullable=False)                                                       # 생일
    gender = db.Column(db.String(20), nullable=False)                                                       # 성별
    phone = db.Column(db.String(30), unique=True, nullable=False)                                           # 전화번호
    profile_image = db.Column(db.String(200), nullable=False, default='user_img/default.jpg')               # 프로필사진
    created_at = db.Column(db.DateTime, nullable=False)                                                     # 생성일

class places(db.Model):                                                                                     # 여행지
    id = db.Column(db.Integer, primary_key=True)                                                            # places 테이블에 여행지 정보가 저장되면 생성 순선대로 자동으로 만들어짐
    province = db.Column(db.String(120), nullable=False)                                                    # 도
    city = db.Column(db.String(120), nullable=False)                                                        # 시/군/구
    name = db.Column(db.String(120), nullable=False)                                                        # 이름
    address = db.Column(db.String(200), nullable=False)                                                     # 주소
    contact_number = db.Column(db.String(50), nullable=False)                                               # 대표 전화번호
    website_url = db.Column(db.String(200), nullable=True)                                                  # 홈페이지
    closed_days = db.Column(db.String(200), nullable=True)                                                  # 휴무일
    operating_hours = db.Column(db.String(200), nullable=True)                                              # 운영시간
    admission_fee = db.Column(db.String(120), nullable=True)                                                # 입장료
    parking_available = db.Column(db.Boolean, nullable=False)                                               # 주차장 유무
    parking_capacity = db.Column(db.String(120), nullable=True)                                             # 주차장 수용 규모
    parking_fee = db.Column(db.String(120), nullable=True)                                                  # 주차장 요금
    requires_reservation = db.Column(db.Boolean, nullable=False)                                            # 예약 필요 여부
    amenities = db.Column(db.Text, nullable=True)                                                           # 부대시설
    description = db.Column(db.Text, nullable=True)                                                         # 소개글
    image_urls = db.Column(db.Text, nullable=True)                                                          # 이미지
    public_transportation = db.Column(db.Text, nullable=True)                                               # 대중교통
    local_currency_available = db.Column(db.Boolean, nullable=False)                                        # 지역화폐
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)                            # 생성시간
    updated_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)  # 수정시간

class activity(db.Model):                                                                                   # 액티비티
    id = db.Column(db.Integer, primary_key=True)                                                            # activity 테이블에 액티비티 정보가 저장되면 생성 순선대로 자동으로 만들어짐
    province = db.Column(db.String(120), nullable=False)                                                    # 도
    city = db.Column(db.String(120), nullable=False)                                                        # 시
    name = db.Column(db.String(120), nullable=False)                                                        # 이름
    address = db.Column(db.String(200), nullable=False)                                                     # 주소
    contact_number = db.Column(db.String(50), nullable=False)                                               # 대표 전화번호
    website_url = db.Column(db.String(200), nullable=True)                                                  # 홈페이지
    closed_days = db.Column(db.String(200), nullable=True)                                                  # 휴무일
    operating_hours = db.Column(db.String(200), nullable=True)                                              # 운영시간
    admission_fee = db.Column(db.String(120), nullable=True)                                                # 입장료
    parking_available = db.Column(db.Boolean, nullable=False)                                               # 주차장 유무
    parking_capacity = db.Column(db.String(120), nullable=True)                                             # 주차장 수용 규모
    parking_fee = db.Column(db.String(120), nullable=True)                                                  # 주차장 요금
    requires_reservation = db.Column(db.Boolean, nullable=False)                                            # 예약 필요 여부
    amenities = db.Column(db.Text, nullable=True)                                                           # 부대시설
    description = db.Column(db.Text, nullable=True)                                                         # 소개글
    image_urls = db.Column(db.Text, nullable=True)                                                          # 이미지
    public_transportation = db.Column(db.Text, nullable=True)                                               # 대중교통
    local_currency_available = db.Column(db.Boolean, nullable=False)                                        # 지역화폐
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)                            # 생성시간
    updated_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)  # 수정시간


class festivals(db.Model):                                                                                  # 축제
    id = db.Column(db.Integer, primary_key=True)                                                            # festivals 테이블에 축제 정보가 저장되면 생성 순선대로 자동으로 만들어짐
    province = db.Column(db.String(120), nullable=False)                                                    # 도
    city = db.Column(db.String(120), nullable=False)                                                        # 시
    name = db.Column(db.String(120), nullable=False)                                                        # 이름
    address = db.Column(db.String(200), nullable=False)                                                     # 주소
    contact_number = db.Column(db.String(50), nullable=False)                                               # 대표 전화번호
    website_url = db.Column(db.String(200), nullable=True)                                                  # 홈페이지
    closed_days = db.Column(db.String(200), nullable=True)                                                  # 휴무일
    operating_hours = db.Column(db.String(200), nullable=True)                                              # 운영시간
    admission_fee = db.Column(db.String(120), nullable=True)                                                # 입장료
    parking_available = db.Column(db.Boolean, nullable=False)                                               # 주차장 유무
    parking_capacity = db.Column(db.String(120), nullable=True)                                             # 주차장 수용 규모
    parking_fee = db.Column(db.String(120), nullable=True)                                                  # 주차장 요금
    requires_reservation = db.Column(db.Boolean, nullable=False)                                            # 예약 필요 여부
    amenities = db.Column(db.Text, nullable=True)                                                           # 부대시설
    description = db.Column(db.Text, nullable=True)                                                         # 소개글
    image_urls = db.Column(db.Text, nullable=True)                                                          # 이미지
    public_transportation = db.Column(db.Text, nullable=True)                                               # 대중교통
    local_currency_available = db.Column(db.Boolean, nullable=False)                                        # 지역화폐
    season = db.Column(db.String(50), nullable=False)                                                       # 시즌
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)                            # 생성시간
    updated_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)  # 수정시간
